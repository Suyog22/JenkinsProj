package com.zensar;

import java.util.Collections;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class MainForLogin {
	
	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(MainForLogin.class);
		app.setDefaultProperties(Collections.singletonMap("server.servlet.context-path", "/mainforlogin"));
		app.run(args);
	}

}
