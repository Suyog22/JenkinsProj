package com.zensar.repo;


import org.springframework.data.jpa.repository.JpaRepository;
import com.zensar.beans.Login;




public interface LoginRepository extends JpaRepository<Login, Integer>{

}
