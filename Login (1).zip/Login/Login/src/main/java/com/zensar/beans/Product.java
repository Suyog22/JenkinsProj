package com.zensar.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Product {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "id")
	private int id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "description")
	private String desc;
	
	@Column(name = "imgpath")
	private String imgpath;

	
	@Column(name = "price")
	private String price;
	
	@Column(name = "quantity")
	private String quantity;
	
	@Column(name = "productdetails")
	private String productdetails;

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", desc=" + desc + ", imgpath=" + imgpath + ", price=" + price
				+ ", quantity=" + quantity + ", productdetails=" + productdetails + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getImgpath() {
		return imgpath;
	}

	public void setImgpath(String imgpath) {
		this.imgpath = imgpath;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getProductdetails() {
		return productdetails;
	}

	public void setProductdetails(String productdetails) {
		this.productdetails = productdetails;
	}

	public Product(int id, String name, String desc, String imgpath, String price, String quantity,
			String productdetails) {
		super();
		this.id = id;
		this.name = name;
		this.desc = desc;
		this.imgpath = imgpath;
		this.price = price;
		this.quantity = quantity;
		this.productdetails = productdetails;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
