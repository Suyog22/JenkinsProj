package com.zensar.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Ratings {
		
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int id;
		
		@Column(name = "productid")
		private int productid;
		
		@Column(name = "ratings")
		private int ratings;
		
		
		@Column(name = "username")
		private String username;


		@Override
		public String toString() {
			return "Ratings [id=" + id + ", productid=" + productid + ", ratings=" + ratings + ", username=" + username
					+ "]";
		}


		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}


		public int getProductid() {
			return productid;
		}


		public void setProductid(int productid) {
			this.productid = productid;
		}


		public int getRatings() {
			return ratings;
		}


		public void setRatings(int ratings) {
			this.ratings = ratings;
		}


		public String getUsername() {
			return username;
		}


		public void setUsername(String username) {
			this.username = username;
		}


		public Ratings(int id, int productid, int ratings, String username) {
			super();
			this.id = id;
			this.productid = productid;
			this.ratings = ratings;
			this.username = username;
		}


		public Ratings() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		
		

}
