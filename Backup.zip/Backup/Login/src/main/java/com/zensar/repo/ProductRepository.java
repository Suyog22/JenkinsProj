package com.zensar.repo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.zensar.beans.Login;
import com.zensar.beans.Product;




public interface ProductRepository extends JpaRepository<Product, Integer>{

}
